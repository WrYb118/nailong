占位压缩包。

把这里换成你真实的作业源码压缩包，
然后在 assets/js/data.js 里修改 files 数组的 url 即可。
